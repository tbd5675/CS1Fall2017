"""
Tate Dyer
Project
drop.py
"""
from utils import *

def sorted_drop_data(data):
    """
    The list is sorted in ascending order based on
    the change in life expectancy from the first value to the second value. The first
    year should be the beginning year of the interval that generated the largest drop
    in life expectancy. The second year should be the ending year of the interval that
    generated the largest drop in life expectancy. Note that a drop in life expectancy
    results in a negative value when computing value2 - value1. Thus the list is
    sorted in ascending order and the largest drop appears first in the list.
    :param data: one or more data structures
    :return: A sorted list of Range structures.
    """
    #range-country, year1, year2, value1, value2
    range_lst=[]
    while data != []:
        #start = float(countries[data[0], data[1]].expectancy[1960])
        #end = float(countries[data[0], data[1]].expectancy[2015])
        drop = 0
        year1 = 1960
        year2 = 2015
        for f in range(1960, 2014):
            if countries[data[0], data[1]].expectancy[f] != "":
                value1=float(countries[data[0], data[1]].expectancy[f])
                for g in range(f+1, 2015):
                    if countries[data[0], data[1]].expectancy[g] != "":
                        value2 = float(countries[data[0], data[1]].expectancy[g])
                        diff=value2-value1
                        if diff<drop:
                            drop=diff
                            year1=f
                            year2=g
        if drop !=0:
            r=Range(data[0], year1, year2, float(countries[data[0], data[1]].expectancy[year1]), float(countries[data[0], data[1]].expectancy[year2]))
            range_lst.append(r)
        data.remove(data[0])
        data.remove(data[0])
    range_lst=sorted(range_lst, key = expectancy_difference, reverse=False)
    return range_lst

def expectancy_difference(country):
    """
    helps with sorting of lsit of structures
    :param country: country in list
    :return: diff between value 2 and 1 which is the greatest drop
    """
    return country.value2-country.value1

def print_top_drops(lst):
    """
    goes through list and prints top 10 drops
    :param lst: list of range structures
    :return:
    """
    for c in range(0,10):
        print(c+1,":", lst[c].country, "from", lst[c].year1, "(", lst[c].value1,") to", lst[c].year2,
              "(", lst[c].value2,"):", expectancy_difference(lst[c]))

def main():
    (c, name_dict, code_dict) = read_data("worldbank_life_expectancy")
    make_incomes(c)
    a =filter_income("all") #list of all countries and their code to be used to acess coutntry dict values
    r=sorted_drop_data(a)
    print("Worst life expectancy drops: 1960 to 2015")
    print_top_drops(r)

if __name__ == '__main__':
    main()