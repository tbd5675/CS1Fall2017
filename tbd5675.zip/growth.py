"""
Tate Dyer
Project
growth.py
"""
from utils import *

sorted_g={}

def sorted_growth_data(data, year1, year2):
    """
    The value stored in this structure is the absolute growth in life expectancy for
    the country between the starting year and the ending year.
    :param data: one or more data structures
    :param year1: starting year
    :param year2: ending year
    :return: list of CountryValue structures, sorted in descending order (highest to lowest)
    """
    lst_g = []  # list of expectanies that can be easily sorted later
    struct_lst = []  # list to put structs in as they are sorted
    (b, c) = data  # list of countries and their codes that included, dictionary of all countries and their structures
    print(b)
    while b != []:
        if countries[(b[0], b[1])].expectancy[year1] != '' and countries[(b[0], b[1])].expectancy[year2] != '':
            value = float(countries[(b[0], b[1])].expectancy[year2])-float(countries[(b[0], b[1])].expectancy[year1])
            sorted_g[value] = (CountryValue(b[0], value))  # puts into dict with le as key and struct as value
            lst_g.append(
                value)  # adds all life expectancies to a list to be sorted later and be plugged into key of dict
            b.remove(b[0])
            b.remove(b[0])
        else:
            b.remove(b[0])
            b.remove(b[0])
    lst_g.sort()
    lst_g.reverse()
    for g in lst_g:  # goes from highest to lowest le and make a list of the structs in the values of the dict created before
        struct_lst.append(sorted_g[g])
    return struct_lst

def print_top_sorted_lst(lst):
    """
        prints out the top 10 countries growth
        :param lst: list of structures in decreasing order
        :return:
        """
    num=1
    for s in lst:
        if num==11:
            break
        print(num, ":", s.country,"",s.value)
        num+=1

def print_bot_sorted_lst(lst):
    """
    prints out the bottom 10 countries growth
    :param lst: list of structures in decreasing order
    :return:
    """
    lst.reverse()
    num=len(lst)
    for s in lst:
        if num== len(lst)-10:
            break
        print(num, ":", s.country,"",s.value)
        num-=1

def main():
    (c, name_dict, code_dict) = read_data("worldbank_life_expectancy")
    make_regions(c)
    make_incomes(c)
    year1 = int(input("Enter starting year of interest (-1 to quit): "))
    year2 = int(input("Enter ending year of interest (-1 to quit): "))
    while year1 != -1 and year2 !=-1:
        if year1 in range(1960, 2016) and year2 in range(1960,2016) and year2>year1:
            region = input("Enter region (type 'all' to consider all): ")
            if region == "all" or region in regions:
                r = filter_region(region)
                income = input("Enter income (type 'all' to consider all): ")
                if income == "all" or income in incomes:
                    i = filter_income(income)
                    b = []
                    for country1 in r:
                        for country2 in i:
                            if country1 == country2:
                                b.append(
                                    country1)  # makes a list of countries and their codes that are in the region and income categories
                    sorted_lst = sorted_growth_data((b, c), year1, year2)
                    print("Top 10 Life Expectancies Growth", year1, "to", year2)
                    print_top_sorted_lst(sorted_lst)
                    print("Bottom 10 Life Expectancies Growth", year1, "to", year2)
                    print_bot_sorted_lst(sorted_lst)
        year1 = int(input("Enter starting year of interest (-1 to quit): "))
        year2 = int(input("Enter ending year of interest (-1 to quit): "))

if __name__ == '__main__':
    main()