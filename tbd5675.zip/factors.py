"""
Tate Dyer
Project
factors.py
"""
from utils import *
import turtle as t

def init():
    """
    starts turtle at 1960,0 mark
    :return:
    """
    t.up()
    t.right(90)
    t.fd(250)
    t.right(90)
    t.fd(200)
    t.right(90)

def make_axis():
    """
    draws the axis for both graphs
    :return:
    """
    t.speed("fastest")
    t.ht()
    t.up()
    t.right(90)
    t.fd(250)
    t.right(90)
    t.fd(200)
    t.right(90)
    t.down()
    t.fd(450)
    t.up()
    t.left(90)
    t.fd(15)
    t.right(90)
    t.write("90")
    t.left(180)
    t.fd(50)
    t.left(180)
    t.write("80")
    t.left(180)
    t.fd(50)
    t.left(180)
    t.write("70")
    t.left(180)
    t.fd(50)
    t.left(180)
    t.write("60")
    t.left(180)
    t.fd(50)
    t.left(180)
    t.write("50")
    t.left(180)
    t.fd(50)
    t.left(180)
    t.write("40")
    t.left(180)
    t.fd(50)
    t.left(180)
    t.write("30")
    t.left(180)
    t.fd(50)
    t.left(180)
    t.write("20")
    t.left(180)
    t.fd(50)
    t.left(180)
    t.write("10")
    t.left(180)
    t.fd(50)
    t.left(180)
    t.write("0")
    t.right(90)
    t.fd(15)
    t.down()
    t.fd(440)
    t.right(90)
    t.up()
    t.fd(25)
    t.right(180)
    t.write("2015")
    t.left(90)
    t.fd(450)
    t.right(90)
    t.write("1960")
    t.right(180)
    t.fd(25)
    t.left(90)
    t.fd(225)
    t.right(90)
    t.write("Year")
    t.right(90)
    t.fd(300)
    t.right(90)
    t.fd(285)
    t.write("Exp.")
    t.fd(10)
    t.write("Life")
    t.home()

def make_key_income():
    """
    draws the keys for the incomes graph
    :return:
    """
    t.left(180)
    t.fd(150)
    t.right(90)
    t.fd(225)
    t.color("orange")
    t.write("High income")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("green")
    t.write("Upper middle income")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("red")
    t.write("Lower middle income")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("blue")
    t.write("Low income")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("black")
    t.home()

def make_key_regions():
    """
    draws the key for the regions graph
    :return:
    """
    t.left(180)
    t.fd(150)
    t.right(90)
    t.fd(180)
    t.color("violet")
    t.write("East Asia & Pacific")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("yellow")
    t.write("North America")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("black")
    t.write("Middle East & North Africa")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("orange")
    t.write("Latin America & Caribbean")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("green")
    t.write("Europe & Central Asia")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("red")
    t.write("South Asia")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("blue")
    t.write("Sub-Saharan Africa")
    t.right(90)
    t.fd(180)
    t.left(90)
    t.fd(10)
    t.right(90)
    t.down()
    t.fd(50)
    t.up()
    t.back(230)
    t.left(90)
    t.fd(10)
    t.color("black")
    t.home()

def make_lst_median_incomes(i): #each income group find median le for each year
    """
    makes a list of median life expectancies starting at 1960 going to 2015 for one income group
    :param i: lst of country names and codes of countries in the income category
    :return: list of median expectancies for each year
    """
    median_lst=[]
    for year in range(1960,2016):
        unsorted_lst=[]
        for f in range(len(i)):
            if f % 2 == 0 and countries[i[f], i[f+1]].expectancy[year] != '':
                value = float(countries[(i[f], i[f+1])].expectancy[year])
                unsorted_lst.append(value) #add one by one le for one year of all countries
        unsorted_lst.sort()
        idx=len(unsorted_lst)//2
        median_lst.append(unsorted_lst[idx])
    return median_lst

def make_lst_median_regions(r): #each income group find median le for each year
    """
    makes a list of median life expectancies starting at 1960 going to 2015 for one income group
    :param r: lst of country names and codes of countries in the income category
    :return: list of median expectancies for each year
    """
    median_lst=[]
    for year in range(1960,2016):
        unsorted_lst=[]
        for f in range(len(r)):
            if f % 2 == 0 and countries[r[f], r[f+1]].expectancy[year] != '':
                value = float(countries[(r[f], r[f+1])].expectancy[year])
                unsorted_lst.append(value)
        unsorted_lst.sort()
        idx=len(unsorted_lst)//2
        median_lst.append(unsorted_lst[idx])
    return median_lst

def graph_income(income):
    """
    graphs a median list for category
    :param income: given income category
    :return:
    """
    i = filter_income(income)
    i_lst = make_lst_median_incomes(i)
    init()
    #t.setworldcoordinates(-200,-250,0,0) #want to set orgin of my graph to the whole windows 0,0?
    x=-200
    y=(i_lst[0] * 5)-250
    t.goto(x, y)
    i_lst.remove(i_lst[0])
    t.down()
    while i_lst !=[]:
        y=(i_lst[0] * 5)-250
        x=x+8
        t.goto(x,y)
        i_lst.remove(i_lst[0])
    t.up()
    t.home()

def graph_region(region):
    """
    graphs a median list for category
    :param region: given region
    :return:
    """
    r = filter_region(region)
    r_lst = make_lst_median_regions(r)
    init() #do the graphing stuff that can be applied to whatever r_lst - atm at 1960,0
    x = -200
    y = (r_lst[0] * 5) - 250
    t.goto(x, y)
    r_lst.remove(r_lst[0])
    t.down()
    while r_lst != []:
        y = (r_lst[0] * 5) - 250
        t.goto(x, y)
        x = x + 8
        r_lst.remove(r_lst[0])
    t.up()
    t.home()

def main():
    (c, name_dict, code_dict) = read_data("worldbank_life_expectancy")
    make_incomes(c)
    make_axis() #450 by 440, 50 between each 10 mark(.2=1) - 8 between each year
    make_key_income()
    t.color("orange")
    graph_income("High income")#graphing function that can be used for all categories using their list
    t.color("green")
    graph_income("Upper middle income")
    t.color("red")
    graph_income("Lower middle income")
    t.color("blue")
    graph_income("Low income")
    input("Hit enter to continue to next graph") #if enter moves to region graph
    t.clear()
    make_regions(c)
    t.color("black")
    make_axis()
    make_key_regions()
    t.color("violet")
    graph_region("East Asia & Pacific")
    t.color("yellow")
    graph_region("North America")
    t.color("black")
    graph_region("Middle East & North Africa")
    t.color("orange")
    graph_region("Latin America & Caribbean")
    t.color("green")
    graph_region("Europe & Central Asia")
    t.color("red")
    graph_region("South Asia")
    t.color("blue")
    graph_region("Sub-Saharan Africa")
    t.done()

if __name__ == '__main__':
    main()