"""
Tate Dyer
Project
utils.py
"""
from rit_lib import *

expectancies= dict() #key is year and value is life expectancy of the country

countries=dict()  #key is touple of their name and code and value is structure

regions=dict() #region is key and value is name and codes alternating in a list
regions_count=dict()

incomes=dict()
incomes_count=dict()

Country=struct_type("Country", (str, "name"), (str, "code"), (dict, "expectancy"), (str, "region"), (str, "income"), (bool, "isGroup"))

CountryValue= struct_type("CountryValue", (str, "country"), (float, "value"))

country_name=dict() #name is key and code is val

country_code=dict() #code is key and name is val

Range=struct_type("Range", (str, "country"), (int, "year1"), (int, "year2"), (float, "value1"), (float, "value2"))

def read_data(filename):
    """
    reads in non empty file
    :param filename: name of file
    :return: dictionary of countries and their data, dictionaries of country name and country code
    """
    file1=filename+"_data.txt"
    file2=filename+"_metadata.txt"
    a=0
    with open(file1) as f:
        for line in f:
            if a==0:
                a+=1
            else:
                expectancies = {}
                #line=f.strip()
                lst=line.split(",")
                year=1960
                for x in lst[2:]:
                    expectancies[year] = x
                    year+=1
                countries[(lst[0], lst[1])]= Country(lst[0], lst[1], expectancies, "", "", False)
                country_name[lst[0]]=lst[1]
                country_code[lst[1]]=lst[0]
    a=0
    with open(file2) as f:
        for line in f:
            if a==0:
                a+=1
            else:
                lst2=line.split(",")
                countries[get_name(lst2[0], country_code), lst2[0]].region = lst2[1]
                countries[get_name(lst2[0], country_code), lst2[0]].income = lst2[2]
                if countries[get_name(lst2[0], country_code), lst2[0]].income != "" and countries[get_name(lst2[0], country_code), lst2[0]].region != "":
                    countries[get_name(lst2[0], country_code), lst2[0]].isGroup = True #makes the countries and territories False because they are not a group
    return countries, country_name, country_code

def make_regions(data):
    """
    given data does through and puts all the countries into region and region count dictionaries
    :param data: countries dictionary
    :return:
    """
    for c in data: #goes through each country in country dict
        if data[c].region != '':
            if data[c].region not in regions.keys():
                regions[data[c].region]= c
                regions_count[data[c].region] = 1
            else:
                regions[data[c].region]+=c #puts country in correct region dict
                regions_count[data[c].region] += 1

def make_incomes(data):
    """
        given data does through and puts all the countries into income and income count dictionaries
        :param data: countries dictionary
        :return:
        """
    for c in data: #goes through each country in country dict
        if data[c].income != '':
            if data[c].income not in incomes.keys():
                incomes[data[c].income]=c #puts country in correct income dict
                incomes_count[data[c].income]= 1
            else:
                incomes[data[c].income] += c
                incomes_count[data[c].income] += 1

def print_region(region):
    """
    prints countries in given region
    :param region:input region
    :return:
    """
    if region=="all":
        for i in regions:
            print("Countries in the ", i, " region:")
            for f in range(len(regions[i])):
                if f % 2 == 0:
                    print(regions[i][f] , " (" , regions[i][f + 1],")")
    else:
        print("Countries in the", region, "region:")
        print(regions[region])
        for g in range (len(regions[region])):
            if g%2==0:
                print(regions[region][g] ," (", regions[region][g+1],")")

def filter_region(region):
    """
    given a region makes a list of countries and their code within it
    :param region: input region
    :return:
    """
    if region=="all":
        lst=[]
        for region in regions:
            for item in regions[region]:
                lst.append(item)
        return lst
    else:
        return regions[region]

def print_income(income):
    """
    prints countries in given income group
    :param income:input income
    :return:
    """
    if income=="all":
        for i in incomes:
            print("Countries in the ", i, " category:")
            for f in range(len(incomes[i])):
                if f % 2 == 0:
                    print(incomes[i][f] ," (", incomes[i][f + 1],")")
    else:
        for g in range (len(incomes[income])):
            if g%2==0:
                print(incomes[income][g] ," (", incomes[income][g+1],")")

def filter_income(income):
    """
    given a income makes a list of countries and their code within it
    :param income: input region
    :return:
    """
    if income=="all":
        lst=[]
        for income in incomes:
            for item in incomes[income]:
                lst.append(item)
        return lst
    else:
        return incomes[income]

def get_code(country, name_dict):
    """
    given country name can get code
    :param country: name of country
    :param name_dict:
    :return: code
    """
    return country_name[country]

def get_name(code, code_dict):
    """
    given a countries code can access its name
    :param code: country code
    :param code_dict:
    :return: name
    """
    return code_dict[code]

def noGroup(countries, name_dict):
    """
    goes through all entities and only counts countries
    :param countries: dict of all entities
    :param name_dict: name and code dict
    :return: number of countries excluding the groups
    """
    entities=len(name_dict)
    not_a_group=0
    for country in countries:
        if countries[country].isGroup is False:
            not_a_group+=1
    ct=entities-not_a_group
    return ct

def output_country_le(name, code):
    """
    prints out the life expectancies for each year for a specific country
    :param name: name of country
    :param code: code
    :return:
    """
    for i in range(1960, 2016): #for loop by year
        print("Year:", i, "Life expectancy:", countries[name,code].expectancy[i])

def main():
    (c, name_dict, code_dict)=read_data("worldbank_life_expectancy")
    print("Total number of entities: ", str(len(name_dict))) #ask how separate all from those only included in c/t
    ct=noGroup(c, name_dict)
    print("Number of countries/territories: ", str(ct))
    print("")
    make_incomes(c)
    make_regions(c)
    print("Regions and their country count: ")
    print("Middle East & North Africa: ", regions_count["Middle East & North Africa"])
    print("Europe & Central Asia", regions_count["Europe & Central Asia"])
    print("North America", regions_count["North America"])
    print("Latin America & Caribbean", regions_count["Latin America & Caribbean"])
    print("South Asia", regions_count["South Asia"])
    print("East Asia & Pacific", regions_count["East Asia & Pacific"])
    print("Sub-Saharan Africa", regions_count["Sub-Saharan Africa"])
    print("")
    print("Income categories and their country count:")
    print("Lower middle income", incomes_count["Lower middle income"])
    print("Upper middle income", incomes_count["Upper middle income"])
    print("Low income", incomes_count["Low income"])
    print("High income", incomes_count["High income"])
    print("")
    region= input("Enter region name: ")
    print_region(region)
    income = input("Enter income category: ")
    print("Countries in the ", income, " income category:")
    print_income(income)
    country = input("Enter name of country or country code (Enter to quit): ")
    while country!="":
        print("Data for", country, ":")
        if country in name_dict: #fix this to find if country is a key in name dict- how?
            code = get_code(country, name_dict)
            output_country_le(country, code)
        else:
            name = get_name(country, code_dict)
            output_country_le(name, country)
        country = input("Enter name of country or country code (Enter to quit): ")
    quit()

if __name__ == '__main__':
    main()